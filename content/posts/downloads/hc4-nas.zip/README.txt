This project is intended to be laser cut from 1/8 inch MDF with dimensions 18 inches by 24 inches, and two copies of the provided STL to be 3d printed. To use an 80mm fan, you need to reuse the connector from the the included 40mm fan and attach it to the new fan. Slightly longer than normal hard drive screws are recommended to thread properly when going through the 1/8 inch MDF. I used m2 bolts to fasten the HC4 to the plate, but m3s might be more suitable. 

Legal:
The iconography is from https://www.gnome.org/

License:
HC4 Nas Enclosure © 2025 by Yannick is licensed under CC BY-SA 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-sa/4.0/